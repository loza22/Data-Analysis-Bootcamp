# Intro_DataAnalytics
Course material, exercises, and solutions sets for the Introductory Data Analytics Bootcamp @ Montgomery College
